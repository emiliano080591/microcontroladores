/*
 * lcd_teclado.c
 *
 * Created: 3/04/2018 8:49:57 a. m.
 * Author : Jjat_Jjat
 */ 

#define F_CPU 16000000 

#include <avr/io.h>

#include <util/delay.h>
#include <avr/pgmspace.h>
#include <inttypes.h>

#include "lcd_lib/lcd_lib.h"




int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

